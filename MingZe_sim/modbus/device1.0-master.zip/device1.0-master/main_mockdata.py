from sensorclass.Flow_End import *
from sensorclass.Flow_Host import *
from TRANSIT import *
from sensorclass.PRESSURE import *


flowend = FlowEnd()
tans = TRANSIT(flowend.PORT,flowend.BAUDRATE,flowend.BYTESIZE,flowend.PARITY,flowend.STOPBITS,flowend.XONXOFF,flowend.SLAVE,flowend.OPTION_READ,flowend.DL_I,flowend.DL_QUANTITY)
tans.Protocol()
# flowend.tran = tans.Transit()
flowend.tran = [0,1,2,3,4,5]
flowend.data = flowend.DataFlowend(flowend.tran)