import modbus_tk.defines as cst
from common_protocol.device_transmit_util import *
from common_protocol.data_transform_util import hex_to_float,hex_to_unlong

#设备型号为DN65的电磁流量计的通信代码
class HostFlowMeter :
    PORT = "/dev/ttyUSB0"
    BAUDRATE = 9600
    BYTESIZE = 8
    PARITY = "N"
    STOPBITS = 1
    XONXOFF = 0
    SLAVE = 1
    OPTION_READ = cst.READ_INPUT_REGISTERS
    ADDRESS_INSTANTANEOUS = 100
    QUANTITY_INSTANTANEOUS = 4
    ADDRESS_TOTAL = 108
    QUANTITY_TOTAL =4
    device_transmit_util = None
    
    def __init__(self):
        self.device_transmit_util = DeviceTransmitUtil(self.PORT,self.BAUDRATE,self.BYTESIZE,self.PARITY,self.STOPBITS,self.XONXOFF,self.SLAVE)
        self.device_transmit_util.init_modbus()
    
    #读取瞬时计数
    #读取为16进制
    #处理后为浮点型
    def read_instantaneous(self):
        if(self.device_transmit_util):
            (instantaneous_flow, instantaneous_veocity, percentage, conductivity) = self.device_transmit_util.execute_modbus(self.OPTION_READ,self.ADDRESS_INSTANTANEOUS,self.QUANTITY_INSTANTANEOUS)
            dataStr = str(hex(instantaneous_flow))[2:].zfill(4)+str(hex(instantaneous_veocity))[2:].zfill(4)+str(hex(percentage))[2:].zfill(4)+str(hex(conductivity))[2:].zfill(4)
            parsed_data = hex_to_float(dataStr)
            return (True,parsed_data)
        else:
            return (False, "device_transmit_util not init")
    #读取总计数
    #读取为16进制
    #转换为无符号长整型
    def read_total(self):
        if(self.device_transmit_util):
            (forward_integer, forward_decimal, reverse_integer, reverse_decimal) = self.device_transmit_util.execute_modbus(self.OPTION_READ,self.ADDRESS_TOTAL,self.QUANTITY_TOTAL)
            dataStr = str(hex(forward_integer))[2:].zfill(4)+str(hex(forward_decimal))[2:].zfill(4)+str(hex(reverse_integer))[2:].zfill(4)+str(hex(reverse_decimal))[2:].zfill(4)
            parsed_data = hex_to_unlong(dataStr)
            return (True, parsed_data)
        else:
            return (False, "device_transmit_util not init")