# coding=utf-8

import modbus_tk.defines as cst
from common_protocol.device_transmit_util import *

#设备型号为HL8023的末端控制面板的通信代码
class EndControlPanel:
    PORT = "/dev/ttyUSB0"
    BAUDRATE = 4800
    BYTESIZE = 8
    PARITY = "O"
    STOPBITS = 1
    XONXOFF = 0
    SLAVE = 5
    OPTION = None
    ADDRESS = None
    QUANTITY = None
    device_transmit_util = None
    data_transform_util = None

    def __init__(self):
        self.device_transmit_util = DeviceTransmitUtil(self.PORT, self.BAUDRATE, self.BYTESIZE, self.PARITY, self.STOPBITS,
                                                  self.XONXOFF, self.SLAVE)
        self.device_transmit_util.init_modbus()
        
    #关机
    def write_close(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 2, 0)
    
    #开机
    def write_open(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 2, 1)
    
    #写入制冷
    def write_refrigeration(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 3, 1)
    
    #写入制热
    def write_heating(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 3, 2)
    
    #写入通风
    def write_ventilation(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 3, 3)
    
    #设置温度
    def write_temperature(self,temperature):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 4, temperature)
    
    #写入风机高速
    def write_high_speed(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 5, 1)
    
    #写入风机中速
    def write_medium_speed(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 5, 2)
    
    #写入风机低速
    def write_low_speed(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 5, 3)
    
    #写入风机自动
    def write_automatic_speed(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 5, 0)
    #设置防冻温度
    def write_antifreeze_temperature(self,temperature):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 7, temperature)
    
    #设置防冻功能关
    def write_antifreeze_close(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 11, 0)
    
    #设置防冻功能开
    def write_antifreeze_open(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 11, 1)
    
    #键盘锁定开
    def lock_open(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 12, 1)
    
    #键盘锁定关
    def lock_close(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 12, 0)
    
    #锁定开关机键
    def lock_switch(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 12, 2)
    
    #锁定模式、定时、风速、上、下键
    def lock_other(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 12, 3)
    
    #读取电动水阀状态（0关，1开）
    def read_water_valve(self):
        return self.transfer_read(cst.READ_COILS, 1, 1)
    
    #读取电动风阀状态（0关，1开）
    def read_air_valve(self):
        return self.transfer_read(cst.READ_COILS, 3, 1)
    
    #读取送风机状态（0关，1高）
    def read_high_blower(self):
        return self.transfer_read(cst.READ_COILS, 5, 1)
    
    #读取送风机状态（0关，1中）
    def read_medium_blower(self):
        return self.transfer_read(cst.READ_COILS, 6, 1)
    
    #读取送风机状态（0关，1低）
    def read_low_blower(self):
        return self.transfer_read(cst.READ_COILS, 7, 1)
    
    #读取电加热器状态（0关，1开）
    def read_heater(self):
        return self.transfer_read(cst.READ_COILS, 8, 1)
    
    #读取温度探头短路状态（0正常、1故障）
    def read_temperature_probe_short_circuit(self):
        return self.transfer_read(cst.READ_DISCRETE_INPUTS, 3, 1)
    
    #读取温度探头开路状态（0正常、1故障）
    def read_temperature_probe_open_circuit(self):
        return self.transfer_read(cst.READ_DISCRETE_INPUTS, 4, 1)
    
    #读取风机盘管状态（0关，1开，2防冻）
    def read_state(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 3, 1)
    
    #读取模式（1制冷，2制热，3通风）
    def read_pattern(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 4, 1)
    
    #读取设置温度
    def read_set_temperature(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 5, 1)
    
    #读取风速（1高速，2中速，3低速，4自动）
    def read_wind_speed(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 6, 1)
    
    #读取设置防冻温度
    def read_antifreeze_temperature(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 8, 1)
    
    #读取通讯检测（每次通讯0/1之间切换）
    def read_communication_detection(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 9, 1)
    
    #读取室内温度
    def read_indoor_temperature(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 10, 1)
    
    #读取防冻功能状态（0关，1开）
    def read_antifreeze_state(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 12, 1)
    
    #读取键盘锁定（0关，1开，2锁定开关机键，3锁定模式、定时、风速、上、下键）
    def read_keyboard_lock(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 13, 1)
    
    def transfer_read(self, Option, Address, Quantity):
        if (self.device_transmit_util):
            data = self.device_transmit_util.execute_modbus(Option, Address, Quantity)
            return (True, data)
        else:
            return (False, "device_transmit_util not init")

    def transfer_read_write(self, Option, Address, Output):
        if (self.device_transmit_util_for_write):
            data = self.device_transmit_util.execute_modbus(Option, Address, Output)
            return (True, data)
        else:
            return (False, "device_transmit_util not init")
