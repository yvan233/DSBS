import modbus_tk.defines as cst
from common_protocol.device_transmit_util import *
from common_protocol.data_transform_util import current_to_temperature,current_to_humidty

#设备型号为HL-SL的温湿度传感器的通信代码
class InsideTempertureHumiditySensor :
    PORT = "/dev/ttyUSB0"
    BAUDRATE = 9600
    BYTESIZE = 8
    PARITY = "N"
    STOPBITS = 1
    XONXOFF = 0
    SLAVE = 1
    OPTION_READ = cst.READ_HOLDING_REGISTERS
    ADDRESS = 51
    QUANTITY = 2
    device_transmit_util = None
    data_transform_util = None
    
    def __init__(self):
        self.device_transmit_util = DeviceTransmitUtil(self.PORT, self.BAUDRATE, self.BYTESIZE, self.PARITY,
                                                       self.STOPBITS, self.XONXOFF, self.SLAVE)
        self.device_transmit_util.init_modbus()
    #读取温度和湿度
    #读取值为电流值
    #通过运算转换为温度值和湿度值
    def read_temperature_humidity(self):
        if (self.device_transmit_util):
            (data_temperature,data_humidity) = self.device_transmit_util.execute_modbus(self.OPTION_READ, self.ADDRESS,
                                                                      self.QUANTITY)
            parsed_data_temperature= current_to_temperature(data_temperature)
            parsed_data_humidity=current_to_humidty(data_humidity)
            return (True, parsed_data_temperature,parsed_data_humidity)
        else:
            return (False, "device_transmit_util not init")
    
