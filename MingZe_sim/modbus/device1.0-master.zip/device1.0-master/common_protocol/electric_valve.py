import modbus_tk.defines as cst
from common_protocol.device_transmit_util import *
from common_protocol.device_transmit_util_for_write import *


# 电动阀的通信代码
class ElectricValve:
    PORT = "/dev/ttyUSB0"
    BAUDRATE = 9600
    BYTESIZE = 8
    PARITY = "N"
    STOPBITS = 1
    XONXOFF = 0
    SLAVE = 1
    OPTION_READ = cst.WRITE_SINGLE_REGISTER
    ADDRESS = 50
    OUTPUT = None
    device_transmit_util_for_write = None
    
    def __init__(self):
        self.device_transmit_util = DeviceTransmitUtil(self.PORT, self.BAUDRATE, self.BYTESIZE, self.PARITY,
                                                       self.STOPBITS, self.XONXOFF, self.SLAVE)
        self.device_transmit_util.init_modbus()

    # 写入数据为0到50000
    # 分别对应全关到全开
    def electric_valve_run(self):
        if (self.device_transmit_util_for_write):
            run_data = self.device_transmit_util_for_write.execute_modbus(self.OPTION_READ, self.ADDRESS,
                                                                         self.OUTPUT)
            
            return (True, run_data)
        else:
            return (False, "device_transmit_util not init")