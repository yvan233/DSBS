# coding=utf-8

from common_protocol.device_transmit_util import *
from common_protocol.data_transform_util import current_to_flow

#设备型号为LWGY-MIK-DN20的末端流量计的通信代码


class EndFlowMeter:
    PORT = "/dev/ttyUSB0"
    BAUDRATE = 9600
    BYTESIZE = 8
    PARITY = "N"
    STOPBITS = 1
    XONXOFF = 0
    SLAVE = 1
    # OPTION_READ = cst.READ_HOLDING_REGISTERS
    # ADDRESS = 50
    # QUANTITY = 8
    device_transmit_util = None
    
    def __init__(self):
        device_transmit_util = DeviceTransmitUtil(self.PORT,self.BAUDRATE,self.BYTESIZE,self.PARITY,self.STOPBITS,self.XONXOFF,self.SLAVE,self.OPTION_READ,self.DL_I,self.DL_QUANTITY)
        device_transmit_util.init_modbus();
    #读取流量值
    #读取电流值
    #电流值通过运算转换流量值
    def read_electric_current(self):
        if (self.device_transmit_util):
            data = self.device_transmit_util.execute_modbus(cst.READ_HOLDING_REGISTERS, 56, 1)
            parsed_data = current_to_flow
            return (True, parsed_data)
        else:
            return (False, "device_transmit_util not init")

