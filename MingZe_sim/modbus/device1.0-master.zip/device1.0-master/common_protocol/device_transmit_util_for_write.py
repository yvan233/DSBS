
import serial
import modbus_tk
import modbus_tk.defines as cst
from modbus_tk import modbus_rtu

class DeviceTransmitUtil:
    def __init__(self,PORT,BAUDRATE,BYTESIZE,PARITY,STOPBITS,XONXOFF,SLAVE):
        self.port=PORT
        self.baudrate=BAUDRATE
        self.bytesize=BYTESIZE
        self.parity=PARITY
        self.stopbits=STOPBITS
        self.xonxoff=XONXOFF
        self.slave=SLAVE

    def init_modbus(self):
        self.master = modbus_rtu.RtuMaster(
            serial.Serial(port=self.port, baudrate=self.baudrate, bytesize=self.bytesize, parity=self.parity, stopbits=self.stopbits, xonxoff=self.xonxoff)
        )
        self.master.set_timeout(5.0)
        self.master.set_verbose(True)
    def execute_modbus(self, function, address, output):
        return self.master.execute(slave=self.slave,function_code=function,starting_address= address,output_value= output)
