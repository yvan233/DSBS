# coding=utf-8

import modbus_tk.defines as cst
from common_protocol.data_transform_util import hex_to_float
from common_protocol.device_transmit_util import *

#设备型号为HL-PS16-MD的压力传感器的通信代码
class PressureSeror:
    PORT = "/dev/ttyUSB0"
    BAUDRATE = 9600
    BYTESIZE = 8
    PARITY = "N"
    STOPBITS = 1
    XONXOFF = 0
    SLAVE = None
    OPTION_READ = cst.READ_HOLDING_REGISTERS
    ADDRESS = 20
    QUANTITY = 2
    device_transmit_util = None
    data_transform_util = None

    def __init__(self):
        self.device_transmit_util = DeviceTransmitUtil(self.PORT, self.BAUDRATE, self.BYTESIZE, self.PARITY, self.STOPBITS,
                                                  self.XONXOFF, self.SLAVE)
        self.device_transmit_util.init_modbus();

    #读取压力值
    #返回值为 （高位，地位）的16进制形式
    #处理后为浮点数
    def read_pressure(self):
        if (self.device_transmit_util):
            (h, l) = self.device_transmit_util.execute_modbus(cst.READ_HOLDING_REGISTERS, 20, 2)
            dataStr = str(hex(h))[2:].zfill(4) + str(hex(l))[2:].zfill(4)
            parsed_data = hex_to_float(dataStr)
            return (True, parsed_data)
        else:
            return (False, "device_transmit_util not init")
