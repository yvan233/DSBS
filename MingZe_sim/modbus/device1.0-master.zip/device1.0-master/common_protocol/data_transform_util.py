# coding=utf-8

import struct

def hex_to_float(h):
    i = int(h, 16)
    return struct.unpack('<f', struct.pack('<I', i))[0]
def hex_to_unlong(h):
    i = int(h, 16)
    return struct.unpack('<L', struct.pack('<I', i))[0]
def current_to_temperature(h):
    return ((h / 2500) - 4) * 25 / 8
def current_to_humidty(h):
    return ((h / 2500) - 4) * 100 / 16
def current_to_pressure_differential(h):
    return (25 * (h / 2500) - 300) / 2
def current_to_flow(h):
    return (7 * (h / 2500) - 28) / 16