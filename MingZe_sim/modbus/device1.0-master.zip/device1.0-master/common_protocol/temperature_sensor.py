# coding=utf-8

from common_protocol.data_transform_util import hex_to_float
from common_protocol.device_transmit_util import *

#设备型号为PT100的末端温度传感器的通信代码
class TemperatureSensor:
    PORT = "/dev/ttyUSB0"
    BAUDRATE = 9600
    BYTESIZE = 8
    PARITY = "N"
    STOPBITS = 1
    XONXOFF = 0
    SLAVE = 1
    OPTION_READ = cst.READ_HOLDING_REGISTERS
    ADDRESS = None
    QUANTITY = 1
    device_transmit_util = None
    data_transform_util = None

    def __init__(self):
        self.device_transmit_util = DeviceTransmitUtil(self.PORT, self.BAUDRATE, self.BYTESIZE, self.PARITY, self.STOPBITS,
                                                  self.XONXOFF, self.SLAVE)
        self.device_transmit_util.init_modbus();

    def read_temperature(self):
        if (self.device_transmit_util):
            temperature_data = self.device_transmit_util.execute_modbus(self.OPTION_READ, self.ADDRESS, self.QUANTITY)
            
            return (True, temperature_data)
        else:
            return (False, "device_transmit_util not init")

