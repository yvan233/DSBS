# coding=utf-8

import modbus_tk.defines as cst
from common_protocol.data_transform_util import current_to_pressure_differential
from common_protocol.device_transmit_util import *

#设备型号为HDP300的压差变送器的通讯代码
class DifferentialPressureSensor:
    PORT = "/dev/ttyUSB0"
    BAUDRATE = 9600
    BYTESIZE = 8
    PARITY = "N"
    STOPBITS = 1
    XONXOFF = 0
    SLAVE = 1
    OPTION_READ = cst.READ_HOLDING_REGISTERS
    ADDRESS = 54
    QUANTITY = 8
    device_transmit_util = None
    data_transform_util = None

    def __init__(self):
        self.device_transmit_util = DeviceTransmitUtil(self.PORT, self.BAUDRATE, self.BYTESIZE, self.PARITY, self.STOPBITS,
                                                  self.XONXOFF, self.SLAVE)
        self.device_transmit_util.init_modbus()
    #读取压差值
    # 读取电流值
    # 电流值通过运算转换为压差
    def read_differential(self):
        if (self.device_transmit_util):
            differential= self.device_transmit_util.execute_modbus(cst.READ_HOLDING_REGISTERS, 54, 1)
            parsed_data = current_to_pressure_differential(differential[4])
            return (True, parsed_data)
        else:
            return (False, "device_transmit_util not init")

