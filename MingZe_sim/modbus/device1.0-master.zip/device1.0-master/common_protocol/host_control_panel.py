# coding=utf-8

import modbus_tk.defines as cst
from common_protocol.device_transmit_util import *

#设备型号为KJRM-120DBMK的主机控制面板的通信代码
class HostControlPanel:
    PORT = "/dev/ttyUSB0"
    BAUDRATE = 9600
    BYTESIZE = 8
    PARITY = "N"
    STOPBITS = 1
    XONXOFF = 0
    SLAVE = 16
    OPTION = None
    ADDRESS = None
    QUANTITY = None
    device_transmit_util = None
    data_transform_util = None

    def __init__(self):
        self.device_transmit_util = DeviceTransmitUtil(self.PORT, self.BAUDRATE, self.BYTESIZE, self.PARITY, self.STOPBITS,
                                                  self.XONXOFF, self.SLAVE)
        self.device_transmit_util.init_modbus()
    #关机
    def write_close(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1601, 8)
    
    #打开制冷模式
    def write_refrigeration(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1601, 1)
    
    #打开制热模式
    def write_heating(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1601, 2)
    
    #打开水泵模式
    def write_water_pump(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1601, 4)
    
    #水温设定
    def write_temperature(self,temperature):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1602, temperature)
    
    #回差设定dIFF
    def write_return_difference(self,difference):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1603, difference)
    
    #上位机锁定
    def lock_upper_computer(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1603, 1)
    
    #上位机接触锁定
    def unlock_upper_computer(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1603, 0)
    
    #线控器并联地址设定
    def write_address(self,address):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1605, address)
    
    #清除故障
    def clear_the_fault(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1606, 1)
    
    #设定实时时钟年低位（00-99）
    def write_year(self,year):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1610, year)
    
    #设定实时时钟月（1-12）
    def write_month(self,month):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1611, month)
    
    #设定实时时钟日（1-x）
    def write_day(self,day):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1612, day)
    
    #设定实时时钟星期（0-6代表周日-周六）
    def write_week(self,week):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1613, week)
    
    #设定实时时钟小时（0-23）
    def write_hour(self,hour):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1614, hour)
    
    #设置实时时钟分钟（0-59）
    def write_minute(self,minute):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1615, minute)
    
    #设置实时时钟秒钟（0-59）
    def write_second(self,second):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1616, second)
    
    #禁止线控器定时
    def lock_timing(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1620, 1)
    
    #取消禁止线控器定时
    def unlock_timing(self):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1620, 0)
    
    #写入定时信息（二进制，000无定时，001定时1，010定时2，011定时1、定时2，100定时3，101定时1、定时3，110定时2、定时3，111，定时1、定时2、定时3，分别对应十进制0-7）
    def write_timing_information(self,information):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1621,information)
    
    #定时1，开小时（0-23）
    def write_first_timing_open_hour(self, hour):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1622,hour)
    
    #定时1，开分钟（0-59）
    def write_first_timing_open_minute(self, minute):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1623, minute)
    
    #定时1，关小时（0-23）
    def write_first_timing_close_hour(self, hour):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1624, hour)
    
    #定时1，关分钟（0-59）
    def write_first_timing_close_minute(self, minute):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1625, minute)
    
    #定时2，开小时（0-23）
    def write_second_timing_open_hour(self, hour):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1626, hour)
    
    #定时2，开分钟（0-59）
    def write_second_timing_open_minute(self, minute):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1627, minute)
    
    #定时2，关小时（0-23）
    def write_second_timing_close_hour(self, hour):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1628, hour)
    
    #定时2，关分钟（0-59）
    def write_second_timing_close_minute(self, minute):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1629, minute)
    
    #定时3，开小时（0-23）
    def write_third_timing_open_hour(self, hour):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1630, hour)
    
    #定时3，开分钟（0-59）
    def write_third_timing_open_minute(self, minute):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1631, minute)
    
    #定时3，关小时（0-23）
    def write_third_timing_close_hour(self, hour):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1632, hour)
    
    #定时3，关分钟（0-59）
    def write_third_timing_close_minute(self, minute):
        return self.transfer_write(cst.WRITE_SINGLE_REGISTER, 1633, minute)
    
    #读取运行模式（8关机模式，1制冷模式，2制热模式，4水泵模式）
    def read_operation_mode(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1601, 1)
    
    #读取水温设定
    def read_temperature(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1602, 1)
    
    #读取回差设定
    def read_return_difference(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1603, 1)
    
    #读取线控器并联地址
    def read_address(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1605, 1)
    
    #读取时钟年份低位
    def read_year(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1610, 1)
    
    #读取时钟月份
    def read_month(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1611, 1)
    
    #读取时钟日
    def read_day(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1612, 1)
    
    #读取时钟星期
    def read_week(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1613, 1)
    
    #读取时钟小时
    def read_hour(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1614, 1)
    
    #读取时钟分钟
    def read_minute(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1615, 1)
    
    #读取线控器定时锁定（1为锁定，0为无锁定）
    def read_lock_timing(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1620, 1)
    
    #读取定时信息（二进制，000无定时，001定时1，010定时2，011定时1、定时2，100定时3，101定时1、定时3，110定时2、定时3，111，定时1、定时2、定时3，分别对应十进制0-7）
    def read_timing_information(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1621, 1)
    
    #读取定时1开小时
    def read_first_timing_open_hour(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1622, 1)
    
    #读取定时1开分钟
    def read_first_timing_open_minute(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1623, 1)
    
    #读取定时1关小时
    def read_first_timing_close_hour(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1624, 1)
    
    #读取定时1关分钟
    def read_first_timing_close_minute(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1625, 1)
    
    #读取定时2开小时
    def read_second_timing_open_hour(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1626, 1)
    
    #读取定时2开分钟
    def read_second_timing_open_minute(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1627, 1)
    
    #读取定时2关小时
    def read_second_timing_close_hour(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1628, 1)
    
    #读取定时2关分钟
    def read_second_timing_close_minute(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1629, 1)
    
    #读取定时3开小时
    def read_third_timing_open_hour(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1630, 1)
    
    #读取定时3开分钟
    def read_third_timing_open_minute(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1631, 1)
    
    #读取定时3关小时
    def read_third_timing_close_hour(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1632, 1)
    
    #读取定时4关分钟
    def read_third_timing_close_minute(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 1633, 1)
    
    #查看本机是否在线（0不在线，1在线）
    def read_pump_state(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+0, 1)
    
    #读取本机运行模式（4除霜，3关机，2水泵，1制热，0制冷）
    def read_pump_pattern(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+1, 1)
    
    #读取板换出水温度
    def read_effluent_temperature(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+2, 1)
    
    #读取冷凝器A温度
    def read_A_condenser_temperature(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+3, 1)
    
    #读取冷凝器B温度
    def read_B_condenser_temperature(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+4, 1)
    
    #读取环境温度
    def read_ambient_temperature(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+5, 1)
    
    #读取板换进水温度
    def read_inlet_temperature(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+6, 1)
    
    #读取A阀开度
    def read_A_valve_opening(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+7, 1)
    
    #读取B阀开度
    def read_B_valve_opening(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+8, 1)
    
    #读取防冻结温度T6
    def read_antifreeze_temperature_T6(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+9, 1)
    
    #读取压缩机A电流
    def read_A_compressor_current(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+10, 1)
    
    #读取压缩机B电流
    def read_B_compressor_current(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+11, 1)
    
    #读取故障状态（1有故障，2无故障）
    def read_fault_status(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+12, 1)
    
    #读取保护状态
    def read_protection_status(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, self.SLAVE*100+13, 1)
    
    #读取总出水温度
    def read_total_effluent_temperature(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 15, 1)
    
    #读取单冷/冷暖机型（0冷暖机，1单冷机）
    def read_type(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 16, 1)
    
    #读取在线机组数（0-16）
    def read_number_online_units(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 17, 1)
    
    #读取制冷设定稳定下限
    def read_refrigeration_temperature_upper_limit(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 18, 1)
    
    #读取制冷设定温度上限
    def read_refrigeration_temperature_lower_limit(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 19, 1)
    
    #读取制热设定温度下限
    def read_heating_temperature_upper_limit(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 20, 1)
    
    #读取制热设定温度上限
    def read_heating_temperature_lower_limit(self):
        return self.transfer_read(cst.READ_HOLDING_REGISTERS, 21, 1)
    
    #保留（1开启，0关闭）
    def read_load_retain(self):
        return self.transfer_read(cst.READ_COILS, self.SLAVE*100+0, 1)

    # 电加热（1开启，0关闭）
    def read_load_electric_heating(self):
        return self.transfer_read(cst.READ_COILS, self.SLAVE*100+1, 1)

    # 水泵（1开启，0关闭）
    def read_load_pump(self):
        return self.transfer_read(cst.READ_COILS, self.SLAVE*100+2, 1)

    # 压缩机B（1开启，0关闭）
    def read_load_B_compressor(self):
        return self.transfer_read(cst.READ_COILS, self.SLAVE*100+3, 1)

    # 四通阀A（1开启，0关闭）
    def read_load_A_four_way_valve(self):
        return self.transfer_read(cst.READ_COILS, self.SLAVE*100+4, 1)

    # 四通阀B（1开启，0关闭）
    def read_load_B_four_way_valve(self):
        return self.transfer_read(cst.READ_COILS, self.SLAVE*100+5, 1)

    # 风机低风（1开启，0关闭）
    def read_load_fan_low_air(self):
        return self.transfer_read(cst.READ_COILS, self.SLAVE*100+6, 1)

    # 风机高风（1开启，0关闭）
    def read_load_fan_high_air(self):
        return self.transfer_read(cst.READ_COILS, self.SLAVE*100+7, 1)
    
    
    def transfer_read(self, Option, Address, Quantity):
        if (self.device_transmit_util):
            data = self.device_transmit_util.execute_modbus(Option, Address, Quantity)
            return (True, data)
        else:
            return (False, "device_transmit_util not init")
    def transfer_write(self, Option, Address, Output):
        if (self.device_transmit_util_for_write):
            data = self.device_transmit_util.execute_modbus(Option, Address, Output)
            return (True, data)
        else:
            return (False, "device_transmit_util not init")