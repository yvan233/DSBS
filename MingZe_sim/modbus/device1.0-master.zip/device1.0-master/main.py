# coding=utf-8

# from sensorclass.Flow_End import *
# from sensorclass.Flow_Host import *
from common_protocol.pressure_sensor import *
from common_protocol.host_flow_meter import *
from common_protocol.inside_temperature_humidity_sensor import *
from common_protocol.temperature_sensor import *
from common_protocol.differential_pressure_sensor import *
# #末端流量计初始化
# end_flow_meter = EndFlowMeter()
# #读取电流值
# end_flow_meter.read_electric_current()

#HL-PS16-MD压力传感器设备通信
#初始化
pressure_sensor = PressureSeror()
#读取压力值
data_pressure = pressure_sensor.read_pressure()
print(data_pressure)

#主管电磁流量计设备通讯
#初始化
host_flow_meter = HostFlowMeter()
#读取瞬时计数
data_instantaneous = host_flow_meter.read_host_flow_instantaneous()
print(data_instantaneous)
#读取累计计数
data_total = host_flow_meter.read_host_flow_total()
print(data_total)

#室内温湿度传感器设备通讯
#初始化
inside_temperature_humidity_sensor = InsideTempertureHumiditySensor()
#读取温度、湿度
data_temperature_humidity = inside_temperature_humidity_sensor.read_temperature_humidity()
print(data_temperature_humidity)

temperature_sensor = TemperatureSensor()
data_temperature = temperature_sensor.read_temperature()
print(data_temperature)

differential_pressure_sensor = DifferentialPressureSensor()
data_differential = DifferentialPressureSensor.read_differential()
print(data_differential)



#
# flowhost = FlowHost()
# TRANSIT(flowhost.PORT,flowhost.BAUDRATE,flowhost.BYTESIZE,flowhost.PARITY,flowhost.STOPBITS,flowhost.XONXOFF,flowhost.SLAVE,flowhost.OPTION_READ,flowhost.INSTANTANEOUS,flowhost.QUANTITY_INSTANTANEOUS)
# TRANSIT.Protocol()
# flowhost.tran = TRANSIT.Transit()
# flowhost.data = FlowHost.DataInstantaneous(flowhost.tran)
#
# TRANSIT(flowhost.PORT,flowhost.BAUDRATE,flowhost.BYTESIZE,flowhost.PARITY,flowhost.STOPBITS,flowhost.XONXOFF,flowhost.SLAVE,flowhost.OPTION_READ,flowhost.TOTAL,flowhost.QUANTITY_TOTAL)
# TRANSIT.Protocol()
# flowhost.tran = TRANSIT.Transit()
# flowhost.data = FlowHost.DataTotal(flowhost.tran)
#
#
# pressure = Pressure()
# TRANSIT(pressure.PORT,pressure.BAUDRATE,pressure.BYTESIZE,pressure.PARITY,pressure.STOPBITS,pressure.XONXOFF,pressure.SLAVE,pressure.OPTION_READ,pressure.PRESSURE,pressure.QUANTITY_PRESSURE)
# TRANSIT.Protocol()
# pressure.tran = TRANSIT.Transit()
# pressure.data = Pressure.Dataend_flow_meter(pressure.tran)
#
