import serial

ser_0 = serial.Serial("/dev/ttyUSB0", 9600)
ans = ser_0.read()
print(ans)
